﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROM02_FINAL_PROTOTYPE_VERSION5
{
    public class TagDetectedEventArgs : EventArgs
    {
        public string TagId { get; set; }
    }

    public class RFIDReader
    {
        public event EventHandler<TagDetectedEventArgs> OnTagDetected;

        
        private bool frequencyHoppingEnabled = false;
        private bool encryptionEnabled = false;
        private bool timingAnalysisEnabled = false;
        private bool locationVerificationEnabled = false;

        
        public bool EncryptionEnabled
        {
            get { return encryptionEnabled; }
        }

        
        public void Start()
        {
            Console.WriteLine("RFID Reader started.");

            
            SimulateTagDetection("RF756DBH");  
        }

        
        public void SimulateTagDetection(string tagId)
        {
            Console.WriteLine("Simulating detection of tag: " + tagId);

            if (frequencyHoppingEnabled)
            {
                Console.WriteLine("Frequency hopping is active, making eavesdropping difficult.");
            }

            if (encryptionEnabled)
            {
                tagId = EncryptTagId(tagId);  
                Console.WriteLine("Tag ID encrypted: " + tagId);
            }

            
            OnTagDetected?.Invoke(this, new TagDetectedEventArgs { TagId = tagId });
        }

        
        public void BlockTag(string tagId)
        {
            Console.WriteLine("Tag " + tagId + " has been blocked.");
            
        }

        
        public void EnableFrequencyHopping(bool enable)
        {
            frequencyHoppingEnabled = enable;
            Console.WriteLine("Frequency Hopping " + (enable ? "enabled." : "disabled."));
        }

        
        public void EnableEncryption(bool enable)
        {
            encryptionEnabled = enable;
            Console.WriteLine("Encryption " + (enable ? "enabled." : "disabled."));
        }

        
        private string EncryptTagId(string tagId)
        {
            
            char[] charArray = tagId.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }

        
        public void EnableTimingAnalysis(bool enable)
        {
            timingAnalysisEnabled = enable;
            Console.WriteLine("Timing Analysis " + (enable ? "enabled." : "disabled."));
        }

        
        public void EnableLocationVerification(bool enable)
        {
            locationVerificationEnabled = enable;
            Console.WriteLine("Location Verification " + (enable ? "enabled." : "disabled."));
        }

        
        private bool CheckTimingAnalysis(string tagId)
        {
            
            Random rand = new Random();
            int simulatedDelay = rand.Next(1, 50); 

            if (simulatedDelay > 30) 
            {
                Console.WriteLine("Potential relay attack detected based on timing analysis.");
                return false;
            }

            Console.WriteLine("Timing analysis passed for tag: " + tagId);
            return true;
        }

        
        private bool CheckLocationVerification(string tagId)
        {
            
            Random rand = new Random();
            int simulatedDistance = rand.Next(1, 100); 

            if (simulatedDistance > 25) 
            {
                Console.WriteLine("Potential relay attack detected based on location verification.");
                return false;
            }

            Console.WriteLine("Location verification passed for tag: " + tagId);
            return true;
        }

        
        public bool CheckForRelayAttacks(string tagId)
        {
            if (timingAnalysisEnabled && !CheckTimingAnalysis(tagId))
            {
                return false;
            }

            if (locationVerificationEnabled && !CheckLocationVerification(tagId))
            {
                return false;
            }

            return true;
        }
    }
}