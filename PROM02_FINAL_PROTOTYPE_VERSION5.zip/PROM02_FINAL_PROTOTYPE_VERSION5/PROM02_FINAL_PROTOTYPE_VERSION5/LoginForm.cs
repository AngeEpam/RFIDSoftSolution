﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace PROM02_FINAL_PROTOTYPE_VERSION5
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        OleDbConnection connection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=db_users.mdb");
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataAdapter adapter = new OleDbDataAdapter();

        private void btnLogin_TextChanged(object sender, EventArgs e)
        {
            connection.Open();
            string login = "SELECT * FROM users_table WHERE Username = '" + txtUsername.Text + "' and Password = '" + txtPassword.Text + "'";
            cmd = new OleDbCommand(login, connection);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read() == true)
            {
                new Form2().Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Wrong Login Credentials");
                txtUsername.Text = "";
                txtPassword.Text = "";
            }
        }

        private void txtClearFields_TextChanged(object sender, EventArgs e)
        {
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtUsername.Focus();
        }

        private void chbShPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chbShPassword.Checked)
            {
                txtPassword.PasswordChar = '\0';


            }
            else
            {
                txtPassword.PasswordChar = '•';

            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            connection.Open();
            string login = "SELECT * FROM users_table WHERE Username = '" + txtUsername.Text + "' and Password = '" + txtPassword.Text + "'";
            cmd = new OleDbCommand(login, connection);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read() == true)
            {
                new Form2().Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Wrong Login Credentials");
                txtUsername.Text = "";
                txtPassword.Text = "";
            }
        }
    }
}
