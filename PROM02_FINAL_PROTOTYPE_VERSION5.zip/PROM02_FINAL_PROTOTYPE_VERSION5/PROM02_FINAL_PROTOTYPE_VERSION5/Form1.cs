using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace PROM02_FINAL_PROTOTYPE_VERSION5
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();

        }
        OleDbConnection connection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=db_users.mdb");
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataAdapter adapter = new OleDbDataAdapter();

        private void Register_Load(object sender, EventArgs e)
        {

        }

       

        private void chbShPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chbShPassword.Checked)
            {
                txtPassword.PasswordChar = '\0';
                txtConfiPass.PasswordChar = '\0';

            }
            else
            {
                txtPassword.PasswordChar = '�';
                txtConfiPass.PasswordChar = '�';
            }
        }

        private void btnClear_TextChanged(object sender, EventArgs e)
        {
            txtConfiPass.Text = "";
            txtPassword.Text = "";
            txtUsername.Text = "";
            txtUsername.Focus();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            new LoginForm().Show();
            this.Hide();

        }

        private void btnRegg_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "" && txtPassword.Text == "" && txtConfiPass.Text == "")
            {
                MessageBox.Show("Make sure all fields are empty, Registration failed");
            }
            else if (txtPassword.Text == txtConfiPass.Text)
            {
                try
                {
                    connection.Open();
                    string register = "INSERT INTO [users_table] ([Us3rname], [P4ssword]) VALUES (?, ?)";
                    using (OleDbCommand cmd = new OleDbCommand(register, connection))
                    {
                        cmd.Parameters.AddWithValue("Us3rname", txtUsername.Text);
                        cmd.Parameters.AddWithValue("P4ssword", txtPassword.Text);
                        cmd.ExecuteNonQuery();
                    }
                    txtConfiPass.Text = "";
                    txtPassword.Text = "";
                    txtUsername.Text = "";
                    MessageBox.Show("Registration successful");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
            else
            {
                MessageBox.Show("Passwords do not match, Registration failed");
            }
        }
    }
    
}
