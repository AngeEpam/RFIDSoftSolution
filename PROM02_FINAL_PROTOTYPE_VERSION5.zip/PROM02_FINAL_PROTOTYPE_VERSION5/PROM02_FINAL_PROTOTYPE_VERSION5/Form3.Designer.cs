﻿namespace PROM02_FINAL_PROTOTYPE_VERSION5
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtTagId = new TextBox();
            btnStartReader = new Button();
            btnStopReader = new Button();
            btnSimulateTag = new Button();
            chkEnableEncryption = new CheckBox();
            chkEnableFrequencyHopping = new CheckBox();
            lstLog = new ListBox();
            chkTimingAnalysis = new CheckBox();
            chkLocationVerification = new CheckBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nirmala UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(316, 44);
            label1.Name = "label1";
            label1.Size = new Size(198, 41);
            label1.TabIndex = 0;
            label1.Text = "RFID Blocker";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Nirmala UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(49, 129);
            label2.Name = "label2";
            label2.Size = new Size(183, 31);
            label2.TabIndex = 1;
            label2.Text = "Detected Tag ID";
            // 
            // txtTagId
            // 
            txtTagId.Location = new Point(316, 134);
            txtTagId.Name = "txtTagId";
            txtTagId.ReadOnly = true;
            txtTagId.Size = new Size(276, 27);
            txtTagId.TabIndex = 2;
            // 
            // btnStartReader
            // 
            btnStartReader.Location = new Point(164, 216);
            btnStartReader.Name = "btnStartReader";
            btnStartReader.Size = new Size(157, 44);
            btnStartReader.TabIndex = 3;
            btnStartReader.Text = "Start Reader";
            btnStartReader.UseVisualStyleBackColor = true;
            // 
            // btnStopReader
            // 
            btnStopReader.Location = new Point(435, 216);
            btnStopReader.Name = "btnStopReader";
            btnStopReader.Size = new Size(157, 44);
            btnStopReader.TabIndex = 4;
            btnStopReader.Text = "Stop Reader";
            btnStopReader.UseVisualStyleBackColor = true;
            // 
            // btnSimulateTag
            // 
            btnSimulateTag.Location = new Point(675, 134);
            btnSimulateTag.Name = "btnSimulateTag";
            btnSimulateTag.Size = new Size(149, 27);
            btnSimulateTag.TabIndex = 5;
            btnSimulateTag.Text = "Simulate Tag";
            btnSimulateTag.UseVisualStyleBackColor = true;
            btnSimulateTag.Click += btnSimulateTag_Click;
            // 
            // chkEnableEncryption
            // 
            chkEnableEncryption.AutoSize = true;
            chkEnableEncryption.Location = new Point(316, 327);
            chkEnableEncryption.Name = "chkEnableEncryption";
            chkEnableEncryption.Size = new Size(150, 24);
            chkEnableEncryption.TabIndex = 6;
            chkEnableEncryption.Text = "Enable Encryption";
            chkEnableEncryption.UseVisualStyleBackColor = true;
            chkEnableEncryption.CheckedChanged += chkEnableEncryption_CheckedChanged;
            // 
            // chkEnableFrequencyHopping
            // 
            chkEnableFrequencyHopping.AutoSize = true;
            chkEnableFrequencyHopping.Location = new Point(316, 383);
            chkEnableFrequencyHopping.Name = "chkEnableFrequencyHopping";
            chkEnableFrequencyHopping.Size = new Size(210, 24);
            chkEnableFrequencyHopping.TabIndex = 7;
            chkEnableFrequencyHopping.Text = "Enable Frequency Hopping";
            chkEnableFrequencyHopping.UseVisualStyleBackColor = true;
            chkEnableFrequencyHopping.CheckedChanged += chkEnableFrequencyHopping_CheckedChanged;
            // 
            // lstLog
            // 
            lstLog.FormattingEnabled = true;
            lstLog.Location = new Point(222, 458);
            lstLog.Name = "lstLog";
            lstLog.Size = new Size(412, 244);
            lstLog.TabIndex = 8;
            // 
            // chkTimingAnalysis
            // 
            chkTimingAnalysis.AutoSize = true;
            chkTimingAnalysis.Location = new Point(553, 327);
            chkTimingAnalysis.Name = "chkTimingAnalysis";
            chkTimingAnalysis.Size = new Size(183, 24);
            chkTimingAnalysis.TabIndex = 9;
            chkTimingAnalysis.Text = "Enable Timing Analysis";
            chkTimingAnalysis.UseVisualStyleBackColor = true;
            chkTimingAnalysis.CheckedChanged += chkTimingAnalysis_CheckedChanged;
            // 
            // chkLocationVerification
            // 
            chkLocationVerification.AutoSize = true;
            chkLocationVerification.Location = new Point(553, 383);
            chkLocationVerification.Name = "chkLocationVerification";
            chkLocationVerification.Size = new Size(216, 24);
            chkLocationVerification.TabIndex = 10;
            chkLocationVerification.Text = "Enable Location Verification";
            chkLocationVerification.UseVisualStyleBackColor = true;
            chkLocationVerification.CheckedChanged += chkLocationVerification_CheckedChanged;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.tech_background;
            ClientSize = new Size(994, 740);
            Controls.Add(chkLocationVerification);
            Controls.Add(chkTimingAnalysis);
            Controls.Add(lstLog);
            Controls.Add(chkEnableFrequencyHopping);
            Controls.Add(chkEnableEncryption);
            Controls.Add(btnSimulateTag);
            Controls.Add(btnStopReader);
            Controls.Add(btnStartReader);
            Controls.Add(txtTagId);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form3";
            Text = "Form3";
            Load += Form3_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtTagId;
        private Button btnStartReader;
        private Button btnStopReader;
        private Button btnSimulateTag;
        private CheckBox chkEnableEncryption;
        private CheckBox chkEnableFrequencyHopping;
        private ListBox lstLog;
        private CheckBox chkTimingAnalysis;
        private CheckBox chkLocationVerification;
    }
}