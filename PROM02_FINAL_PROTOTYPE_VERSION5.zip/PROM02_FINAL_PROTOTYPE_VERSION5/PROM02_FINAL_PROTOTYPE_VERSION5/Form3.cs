﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROM02_FINAL_PROTOTYPE_VERSION5
{
    public partial class Form3 : Form
    {
        private RFIDReader reader;
        public Form3()
        {
            InitializeComponent();
            InitializeRFIDReader();
        }

        private void InitializeRFIDReader()
        {
            
            reader = new RFIDReader();
            reader.OnTagDetected += Reader_OnTagDetected;
            reader.EnableEncryption(false);  
            reader.EnableFrequencyHopping(false);  
            reader.EnableTimingAnalysis(false);  
            reader.EnableLocationVerification(false); 
        }

        private void Reader_OnTagDetected(object sender, TagDetectedEventArgs e)
        {
            string tagId = e.TagId;
            txtTagId.Text = tagId;

            
            lstLog.Items.Add("Tag detected: " + tagId);

            
            HandleDetectedTag(tagId);
        }

        private void HandleDetectedTag(string tagId)
        {
            if (IsAuthorizedTag(tagId))
            {
                
                MessageBox.Show("Authorized tag detected: " + tagId);
                lstLog.Items.Add("Authorized tag detected: " + tagId);
            }
            else
            {
                
                BlockUnauthorizedAccess(tagId);
            }
        }

        private bool IsAuthorizedTag(string tagId)
        {
            
            var authorizedTags = new[] { "RF5575DB", "BD876E08" }; 
            return Array.Exists(authorizedTags, tag => tag == tagId);
        }

        private void BlockUnauthorizedAccess(string tagId)
        {
            
            lstLog.Items.Add("Authorised access attempt: " + tagId);
            MessageBox.Show("Authorised access detected: " + tagId);

            
            reader.BlockTag(tagId); 
        }

        private void btnSimulateTag_Click(object sender, EventArgs e)
        {
            reader.Start();
            txtTagId.AppendText("Simulating RFID Tag Detection...\n");
            reader.SimulateTagDetection("BD876E08");  
        }

        private void chkEnableEncryption_CheckedChanged(object sender, EventArgs e)
        {
            reader.EnableEncryption(chkEnableEncryption.Checked);
            txtTagId.AppendText($"Encryption {(chkEnableEncryption.Checked ? "enabled" : "disabled")}.\n");
            lstLog.Items.Add("91440c60b58122507cb87420ee2d495");
            lstLog.Items.Add("5528afcd4daf93e853d9acb3653f1ed8");

        }

        private void chkEnableFrequencyHopping_CheckedChanged(object sender, EventArgs e)
        {
            reader.EnableFrequencyHopping(chkEnableFrequencyHopping.Checked);
            txtTagId.AppendText($"Frequency Hopping {(chkEnableFrequencyHopping.Checked ? "enabled" : "disabled")}.\n");
            lstLog.Items.Add("Frequency Channel Switched");
        }

        private void chkTimingAnalysis_CheckedChanged(object sender, EventArgs e)
        {
            reader.EnableTimingAnalysis(chkTimingAnalysis.Checked);
            txtTagId.AppendText($"Timing Analysis {(chkTimingAnalysis.Checked ? "enabled" : "disabled")}.\n");
            lstLog.Items.Add("Timing Analysis Enabled");
        }

        private void chkLocationVerification_CheckedChanged(object sender, EventArgs e)
        {
            reader.EnableLocationVerification(chkLocationVerification.Checked);
            txtTagId.AppendText($"Location Verification {(chkLocationVerification.Checked ? "enabled" : "disabled")}.\n");
            lstLog.Items.Add("Distance of less than 50m Set");
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}