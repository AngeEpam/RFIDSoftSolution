﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Windows.Forms;


namespace PROM02_FINAL_PROTOTYPE_VERSION5
{
    public partial class Form2 : Form
    {
        private byte[] key;
        private byte[] iv;
        public Form2()
        {
            InitializeComponent();
            GenerateKeyAndIV();
        }
        private void GenerateKeyAndIV()
        {
            key = new byte[16];
            iv = new byte[16];

            using (RandomNumberGenerator rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(key);
                rng.GetBytes(iv);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            string keyToEncrypt = txtEncrypt.Text;

            if (!string.IsNullOrEmpty(keyToEncrypt))
            {
                byte[] encryptedKey = Encrypt(keyToEncrypt, key, iv);
                string encryptedKeyString = Convert.ToBase64String(encryptedKey);
                listBox1.Items.Add(encryptedKeyString);
            }
            else
            {
                MessageBox.Show("Please enter a key to encrypt.");
            }
        }
        private static byte[] Encrypt(string simpletext, byte[] key, byte[] iv)
        {
            byte[] cipheredtext;
            using (Aes aes = Aes.Create())
            {
                ICryptoTransform encryptor = aes.CreateEncryptor(key, iv);
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter streamWriter = new StreamWriter(cryptoStream))
                        {
                            streamWriter.Write(simpletext);
                        }
                        cipheredtext = memoryStream.ToArray();
                    }
                }
            }
            return cipheredtext;
        }
        private static string Decrypt(byte[] cipheredtext, byte[] key, byte[] iv)
        {
            string simpletext = string.Empty;
            using (Aes aes = Aes.Create())
            {
                ICryptoTransform decryptor = aes.CreateDecryptor(key, iv);
                using (MemoryStream memoryStream = new MemoryStream(cipheredtext))
                {
                    using (CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader streamReader = new StreamReader(cryptoStream))
                        {
                            simpletext = streamReader.ReadToEnd();
                        }
                    }
                }
            }
            return simpletext;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Form3().Show();
            this.Hide();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
