﻿namespace PROM02_FINAL_PROTOTYPE_VERSION5
{
    partial class Register
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtUsername = new TextBox();
            txtPassword = new TextBox();
            label3 = new Label();
            label4 = new Label();
            chbShPassword = new CheckBox();
            button1 = new Button();
            btnClear = new TextBox();
            label5 = new Label();
            label6 = new Label();
            txtConfiPass = new TextBox();
            btnRegg = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("MS UI Gothic", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.HotTrack;
            label1.Location = new Point(115, 60);
            label1.Name = "label1";
            label1.Size = new Size(194, 34);
            label1.TabIndex = 0;
            label1.Text = "Get Started";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(115, 127);
            label2.Name = "label2";
            label2.Size = new Size(89, 23);
            label2.TabIndex = 1;
            label2.Text = "Username";
            // 
            // txtUsername
            // 
            txtUsername.BackColor = Color.FromArgb(230, 231, 233);
            txtUsername.BorderStyle = BorderStyle.None;
            txtUsername.Font = new Font("MS UI Gothic", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtUsername.Location = new Point(115, 153);
            txtUsername.Multiline = true;
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(216, 28);
            txtUsername.TabIndex = 2;
            // 
            // txtPassword
            // 
            txtPassword.BackColor = Color.FromArgb(230, 231, 233);
            txtPassword.BorderStyle = BorderStyle.None;
            txtPassword.Font = new Font("MS UI Gothic", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPassword.Location = new Point(115, 220);
            txtPassword.Multiline = true;
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '•';
            txtPassword.Size = new Size(216, 28);
            txtPassword.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(115, 194);
            label3.Name = "label3";
            label3.Size = new Size(84, 23);
            label3.TabIndex = 3;
            label3.Text = "Password";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(115, 267);
            label4.Name = "label4";
            label4.Size = new Size(155, 23);
            label4.TabIndex = 5;
            label4.Text = "Confirm Password";
            // 
            // chbShPassword
            // 
            chbShPassword.AutoSize = true;
            chbShPassword.Cursor = Cursors.Hand;
            chbShPassword.FlatStyle = FlatStyle.Flat;
            chbShPassword.Location = new Point(337, 222);
            chbShPassword.Name = "chbShPassword";
            chbShPassword.Size = new Size(151, 27);
            chbShPassword.TabIndex = 7;
            chbShPassword.Text = "Show Password";
            chbShPassword.UseVisualStyleBackColor = true;
            chbShPassword.CheckedChanged += chbShPassword_CheckedChanged;
            // 
            // button1
            // 
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = Color.White;
            button1.Location = new Point(115, 448);
            button1.Name = "button1";
            button1.Size = new Size(216, 35);
            button1.TabIndex = 8;
            button1.Text = "Register";
            button1.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            btnClear.BackColor = SystemColors.HotTrack;
            btnClear.BorderStyle = BorderStyle.None;
            btnClear.Cursor = Cursors.Hand;
            btnClear.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnClear.ForeColor = Color.White;
            btnClear.Location = new Point(115, 437);
            btnClear.Multiline = true;
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(216, 28);
            btnClear.TabIndex = 9;
            btnClear.Text = "Clear";
            btnClear.TextAlign = HorizontalAlignment.Center;
            btnClear.TextChanged += btnClear_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(115, 499);
            label5.Name = "label5";
            label5.Size = new Size(212, 23);
            label5.TabIndex = 10;
            label5.Text = "Already have an account?";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = SystemColors.HotTrack;
            label6.Cursor = Cursors.Hand;
            label6.Font = new Font("Nirmala UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(157, 540);
            label6.Name = "label6";
            label6.Size = new Size(126, 17);
            label6.TabIndex = 11;
            label6.Text = "Back to Login Page";
            label6.Click += label6_Click;
            // 
            // txtConfiPass
            // 
            txtConfiPass.BackColor = Color.FromArgb(230, 231, 233);
            txtConfiPass.BorderStyle = BorderStyle.None;
            txtConfiPass.Font = new Font("MS UI Gothic", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtConfiPass.Location = new Point(115, 302);
            txtConfiPass.Multiline = true;
            txtConfiPass.Name = "txtConfiPass";
            txtConfiPass.Size = new Size(216, 28);
            txtConfiPass.TabIndex = 12;
            // 
            // btnRegg
            // 
            btnRegg.BackColor = SystemColors.HotTrack;
            btnRegg.ForeColor = Color.White;
            btnRegg.Location = new Point(115, 346);
            btnRegg.Name = "btnRegg";
            btnRegg.Size = new Size(212, 39);
            btnRegg.TabIndex = 13;
            btnRegg.Text = "Register";
            btnRegg.UseVisualStyleBackColor = false;
            btnRegg.Click += btnRegg_Click;
            // 
            // Register
            // 
            AutoScaleDimensions = new SizeF(10F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(525, 626);
            Controls.Add(btnRegg);
            Controls.Add(txtConfiPass);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(btnClear);
            Controls.Add(button1);
            Controls.Add(chbShPassword);
            Controls.Add(label4);
            Controls.Add(txtPassword);
            Controls.Add(label3);
            Controls.Add(txtUsername);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ForeColor = SystemColors.ControlDark;
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "Register";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Register_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Label label3;
        private Label label4;
        private CheckBox chbShPassword;
        private Button button1;
        private TextBox btnClear;
        private Label label5;
        private Label label6;
        private TextBox txtConfiPass;
        private Button btnRegg;
    }
}
